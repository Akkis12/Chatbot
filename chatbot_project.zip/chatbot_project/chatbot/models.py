
from django.db import models

class UploadData(models.Model):
    id = models.AutoField(primary_key=True)
    data_file = models.FileField(upload_to='uploads/')
