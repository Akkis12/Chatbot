from django.shortcuts import render

# Create your views here.
# chatbot/views.py

from django.shortcuts import render
from chatbot.forms import UploadForm
from chatbot.models import UploadData

def upload_data(request):
    if request.method == 'POST':
        form = UploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            # Process the uploaded data here
            return render(request, 'upload_success.html', {'form': form})
    else:
        form = UploadForm()
    return render(request, 'upload_data.html', {'form': form})
