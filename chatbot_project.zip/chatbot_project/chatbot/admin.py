
from django.contrib import admin
from chatbot.models import UploadData

class UploadDataAdmin(admin.ModelAdmin):
    list_display = ['id', 'data_file']
admin.site.register(UploadData,UploadDataAdmin)

