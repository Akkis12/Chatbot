
from django import forms
from chatbot.models import UploadData

class UploadForm(forms.ModelForm):
    class Meta:
        model = UploadData
        fields = ['data_file']
